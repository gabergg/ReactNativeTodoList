import React, { Component, PropTypes } from 'react'
import { TouchableOpacity, Text, StyleSheet } from 'react-native'

const styles = StyleSheet.create({
})

export default class Footer extends Component {
  render() {
    return null
  }
}
