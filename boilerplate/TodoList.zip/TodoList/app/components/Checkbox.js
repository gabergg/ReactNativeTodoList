import React, { Component, PropTypes } from 'react'
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native'

const styles = StyleSheet.create({
})

export default class Checkbox extends Component {
  render() {
    return null
  }
}
