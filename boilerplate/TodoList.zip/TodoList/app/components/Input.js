import React, { Component, PropTypes } from 'react'
import { TextInput, View, StyleSheet } from 'react-native'

const styles = StyleSheet.create({
})

export default class Input extends Component {
  render() {
    return null
  }
}
